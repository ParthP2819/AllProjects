﻿using ExamRetest.Data;
using ExamRetest.Models;
using ExamRetest.Models.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace ExamRetest.Controllers
{
    public class EmployeeController : Controller
    {
        private ApplicationDbContext _db;

		public EmployeeController(ApplicationDbContext db)
		{
			_db = db;
		}

		public IActionResult Index()
        {
            return View();
        }

        //GET
        public IActionResult Upsert(int? id)
        {
            EmployeeVM employeeVM = new() 
            { 
                employee=new(),
                roleList = _db.roles.Select(a=> new SelectListItem { Text = a.Name, Value = a.Id.ToString()})
            };
			if (id == 0 || id == null)
			{
				return View(employeeVM);
			}
			else
			{
				var employeefromdb = _db.employees.Find(id);

				if (employeefromdb == null)
				{
					return NotFound();
				}
				return View(employeefromdb);
			}
        }

        [HttpPost]
		public IActionResult Upsert(EmployeeDetail obj)
		{
			return View();
		}
	}
}
